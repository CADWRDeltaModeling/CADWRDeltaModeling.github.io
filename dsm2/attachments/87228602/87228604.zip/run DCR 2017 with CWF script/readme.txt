to generate DSM2 planning boundary conditions from CALSIM II DCR 2017 (2020 development level), run 

cd studies\planning
prepro_planning_existing config_planning_existing.inp

The script runs well except for a warning error:
WARNING: Could not open/create prefs root node Software\JavaSoft\Prefs at root 0x80000002. Windows RegCreateKeyEx(...) returned error code 5.

I think this is caused by a older version Java that VScript used and should be harmless.

The generated boundary files are in studies\planning\timeseries

The script to generate the boundary conditions is from CalWaterFix (CWF) that is for the output of a older version of CALSIM II  with 2005 development level.  I compared the boundary conditions generated with those from CWF.  There are pretty noticeable differences. They could be caused by the development level assumption, but I haven't figured out exactly. 

